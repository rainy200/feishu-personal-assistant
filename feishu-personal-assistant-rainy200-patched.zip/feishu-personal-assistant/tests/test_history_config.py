"""历史查询、隔离、持久化与配置校验回归测试（不访问外部服务）。"""
import contextlib
import io
import os
from pathlib import Path
import sys
import tempfile
import json
from types import SimpleNamespace
import unittest
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from feishu_assistant.config import Config, load_config
from feishu_assistant.db import Database
from feishu_assistant.history import HistoryCommands, parse_history_command
from feishu_assistant.router import Router, HISTORY_MSG_CHARS
from feishu_assistant.llm import LLMError, parse_json
from smoke_test import FakeBot, FakeLLM


class HistoryTests(unittest.TestCase):
    def setUp(self):
        self.env = patch.dict(os.environ, {}, clear=True)
        self.env.start()
        self.addCleanup(self.env.stop)
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.db = Database(str(Path(self.tmp.name) / "test.db"))
        self.addCleanup(self.db.close)
        self.cfg = Config({"llm": {"api_key": "test-only"}})
        self.bot = FakeBot()
        self.router = Router(self.cfg, self.db, FakeLLM(), self.bot)
        self.cid = self.router._active_conv("u1")
        self.commands = HistoryCommands(self.db)

    def say(self, text, chat_type="p2p"):
        self.bot.replies.clear()
        self.router.handle_message("u1", "c1", "m1", "text", {"text": text, "_chat_type": chat_type})
        return self.bot.replies[-1]

    def test_command_parsing(self):
        self.assertEqual(parse_history_command(" 对话历史 2 "), ("history", "2"))
        self.assertEqual(parse_history_command("搜索历史 SQL 注入"), ("search", "SQL 注入"))
        self.assertIsNone(parse_history_command("请帮我分析对话历史"))

    def test_pagination_order_and_boundaries(self):
        for i in range(12):
            self.db.add_conv_message(self.cid, "user", "消息%02d" % i)
        first = self.say("对话历史")
        self.assertIn("消息02", first)
        self.assertNotIn("消息01", first)
        self.assertLess(first.index("消息02"), first.index("消息11"))
        self.assertIn("下一页：对话历史 2", first)
        second = self.say("对话历史 2")
        self.assertIn("消息00", second)
        self.assertNotIn("消息02", second)
        self.assertIn("还没有历史消息", self.say("对话历史 3"))

    def test_empty_and_invalid_arguments(self):
        self.assertIn("还没有历史消息", self.say("对话历史"))
        for value in ("0", "-1", "1.5", "二", "1" * 200):
            self.assertIn("页码", self.say("对话历史 " + value))
        self.assertIn("关键词", self.say("搜索历史"))
        self.assertIn("关键词", self.say("搜索历史 " + "字" * 101))
        self.assertIn("没有找到", self.say("搜索历史 不存在"))

    def test_search_all_owned_conversations_only(self):
        second = self.db.create_conversation("u1", "求职")
        other = self.db.create_conversation("u2", "他人的会话")
        self.db.add_conv_message(self.cid, "user", "简历旧记录")
        self.db.add_conv_message(second, "assistant", "简历新记录")
        self.db.add_conv_message(other, "user", "简历私密内容")
        reply = self.say("搜索历史 简历")
        self.assertIn("简历旧记录", reply)
        self.assertIn("简历新记录", reply)
        self.assertNotIn("私密内容", reply)
        self.assertLess(reply.index("简历新记录"), reply.index("简历旧记录"))
        self.assertEqual(self.db.history_page("u1", other), [])

    def test_search_literal_wildcards_and_sql(self):
        for text in ("100%", "snake_case", "C:\\temp", "plain", "' OR 1=1 --"):
            self.db.add_conv_message(self.cid, "user", text)
        for keyword in ("%", "_", "\\", "' OR 1=1 --"):
            rows = self.db.search_conversation_messages("u1", keyword)
            self.assertEqual(len(rows), 1)
            self.assertIn(keyword, rows[0]["content"])

    def test_search_limit_and_match_excerpt(self):
        for _ in range(12):
            self.db.add_conv_message(self.cid, "user", "长" * 600 + "关键词" + "尾" * 600)
        result = self.say("搜索历史 关键词")
        self.assertIn("最新 10 条", result)
        self.assertIn("还有更多匹配", result)
        self.assertEqual(result.count("关键词"), 11)  # 10 条摘录 + 提示
        self.assertLess(len(result), 3000)

    def test_queries_do_not_call_llm_or_pollute_history_or_session(self):
        self.router.llm = None  # 任何模型调用都会失败
        self.router._set_session("u1", {"module": "quiz", "sentinel": 1})
        before = len(self.db.get_conv_messages(self.cid, 100))
        for text in ("帮助", "对话历史", "搜索历史 简历"):
            self.assertTrue(self.say(text))
        self.assertEqual(len(self.db.get_conv_messages(self.cid, 100)), before)
        self.assertEqual(self.router._session("u1"), {"module": "quiz", "sentinel": 1})

    def test_history_available_without_llm_config(self):
        self.router.cfg = Config({})
        self.assertIn("还没有历史消息", self.say("对话历史"))
        self.assertIn("使用帮助", self.say("帮助"))

    def test_history_not_disclosed_in_group_or_unknown_chat(self):
        self.db.add_conv_message(self.cid, "user", "私密标记")
        for chat_type in ("group", None):
            for command in ("对话历史", "搜索历史 私密"):
                reply = self.say(command, chat_type)
                self.assertIn("私聊", reply)
                self.assertNotIn("私密标记", reply)

    def test_chat_type_comes_from_event_not_message_body(self):
        from feishu_assistant.bot import FeishuBot
        bot = FeishuBot.__new__(FeishuBot)
        bot.db = self.db
        bot._handler = self.router.handle_message
        message = SimpleNamespace(
            message_id="group-event", chat_id="group", chat_type="group", message_type="text",
            mentions=[SimpleNamespace(key="@bot")],
            content=json.dumps({"text": "@bot 对话历史", "_chat_type": "p2p"}),
        )
        event = SimpleNamespace(message=message, sender=SimpleNamespace(sender_id=SimpleNamespace(open_id="u1")))
        with patch("feishu_assistant.bot.threading.Thread"):
            bot._do_message_receive(SimpleNamespace(event=event))
        payload = json.loads(self.db.inbox_pending()[0]["payload"])
        self.assertEqual(payload["content"]["_chat_type"], "group")

    def test_full_text_persists_but_restored_context_is_bounded(self):
        content = "字" * 900 + "末尾检索词"
        self.router._record("u1", content, content)
        self.assertEqual(self.db.get_conv_messages(self.cid, 2)[0]["content"], content)
        fresh_db = Database(str(Path(self.tmp.name) / "test.db"))
        self.addCleanup(fresh_db.close)
        restored = Router(self.cfg, fresh_db, FakeLLM(), self.bot)
        self.assertEqual(len(restored._history("u1")[0]["content"]), HISTORY_MSG_CHARS)
        self.assertEqual(len(fresh_db.search_conversation_messages("u1", "末尾检索词")), 2)

    def test_legacy_database_and_index_creation_are_compatible(self):
        self.db.add_conv_message(self.cid, "user", "旧版截断消息")
        self.db._execute("DROP INDEX idx_conv_messages_conv_id_id")
        fresh = Database(str(Path(self.tmp.name) / "test.db"))
        self.addCleanup(fresh.close)
        self.assertEqual(fresh.history_page("u1", self.cid)[0]["content"], "旧版截断消息")
        self.assertTrue(fresh._query("SELECT name FROM sqlite_master WHERE name='idx_conv_messages_conv_id_id'"))

    def test_unauthorized_delete_preserves_messages(self):
        self.db.add_conv_message(self.cid, "user", "保留")
        self.assertFalse(self.db.delete_conversation(self.cid, "u2"))
        self.assertEqual(len(self.db.get_conv_messages(self.cid, 10)), 1)
        self.assertTrue(self.db.delete_conversation(self.cid, "u1"))
        self.assertEqual(self.db.get_conv_messages(self.cid, 10), [])

    def test_exchange_rejects_other_owner_and_is_atomic(self):
        with self.assertRaises(ValueError):
            self.db.add_conv_exchange(self.cid, "u2", "bad", "bad")
        self.db._execute("CREATE TRIGGER fail_assistant BEFORE INSERT ON conv_messages "
                         "WHEN NEW.role='assistant' BEGIN SELECT RAISE(ABORT, 'test'); END")
        with self.assertRaises(Exception):
            self.db.add_conv_exchange(self.cid, "u1", "rollback", "rollback")
        self.assertEqual(self.db.get_conv_messages(self.cid, 10), [])

    def test_stale_foreign_and_invalid_active_ids_recover(self):
        other = self.db.create_conversation("u2", "private")
        for saved in ("999999", str(other), "broken"):
            self.db.kv_set("conv_active_u1", saved)
            self.router._conv_active.clear()
            self.assertEqual(self.router._active_conv("u1"), self.cid)

    def test_delete_active_resets_transient_state(self):
        self.router._ctx("u1")["last_resume_text"] = "old"
        self.router._set_session("u1", {"module": "quiz"})
        self.router._conv_delete("u1", "1")
        self.assertIsNone(self.router._session("u1"))
        self.assertNotIn("last_resume_text", self.router._ctx("u1"))
        self.assertNotEqual(self.router._active_conv("u1"), self.cid)

    def test_router_errors_do_not_echo_exception(self):
        with patch.object(self.router, "_handle_text", side_effect=RuntimeError("PRIVATE_TOKEN")):
            reply = self.say("hello")
        self.assertNotIn("PRIVATE_TOKEN", reply)
        self.assertIn("帮助", reply)
        with self.assertRaises(LLMError) as error:
            parse_json("PRIVATE_TOKEN")
        self.assertNotIn("PRIVATE_TOKEN", str(error.exception))


class ConfigTests(unittest.TestCase):
    def setUp(self):
        env = patch.dict(os.environ, {}, clear=True)
        env.start()
        self.addCleanup(env.stop)

    def test_env_overrides_without_mutating_input(self):
        data = {"llm": {"api_key": "yaml-key"}}
        with patch.dict(os.environ, {"LLM_API_KEY": "env-key", "FEISHU_APP_ID": "cli_test", "FEISHU_APP_SECRET": "test"}):
            cfg = Config(data)
        self.assertEqual(cfg.llm_api_key, "env-key")
        self.assertTrue(cfg.feishu_configured)
        self.assertEqual(data["llm"]["api_key"], "yaml-key")

    def test_environment_only_and_explicit_empty_override(self):
        with patch("feishu_assistant.config.CONFIG_PATH", "missing-config-test.yaml"):
            with patch.dict(os.environ, {"FEISHU_APP_ID": "cli_test", "FEISHU_APP_SECRET": "test"}):
                self.assertTrue(load_config(exit_on_missing=True).feishu_configured)
        with patch.dict(os.environ, {"LLM_API_KEY": ""}):
            self.assertFalse(Config({"llm": {"api_key": "yaml"}}).llm_configured)

    def test_invalid_shapes_and_values_are_safe(self):
        for data in ([], "secret", {"llm": "secret"}, {"feishu": {"app_secret": 123}},
                     {"paper": {"search_top_n": 0}}, {"github": {"poll_minutes": True}},
                     {"llm": {"temperature": "secret"}}, {"llm": {"temperature": float("nan")}},
                     {"schedule": {"morning_brief": "25:00"}}):
            with self.subTest(data_type=type(data).__name__):
                with self.assertRaises(ValueError) as error:
                    Config(data)
                self.assertNotIn("secret", str(error.exception).replace("app_secret", "field"))

    def test_yaml_error_does_not_echo_source_line(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "config.yaml"
            path.write_text('llm: [PRIVATE_TOKEN', encoding="utf-8")
            with patch("feishu_assistant.config.CONFIG_PATH", str(path)):
                with self.assertRaises(ValueError) as error:
                    load_config()
                self.assertNotIn("PRIVATE_TOKEN", str(error.exception))
                output = io.StringIO()
                with contextlib.redirect_stdout(output), self.assertRaises(SystemExit):
                    load_config(exit_on_missing=True)
                self.assertIn("配置错误", output.getvalue())
                self.assertNotIn("PRIVATE_TOKEN", output.getvalue())

    def test_example_has_no_working_credentials(self):
        import yaml
        path = Path(__file__).resolve().parents[1] / "config.example.yaml"
        cfg = Config(yaml.safe_load(path.read_text(encoding="utf-8")))
        self.assertFalse(cfg.feishu_configured)
        self.assertFalse(cfg.llm_configured)


if __name__ == "__main__":
    unittest.main()
